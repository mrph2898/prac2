#!/bin/bash
CC="gcc"
OBJDIR="./Objfiles"
TESTDIR="./Tests"
SW="./stage1.c"
SOW="$OBJDIR/s1.o"
PW="$OBJDIR/s1"
OPTIONS_CC=" -Wall -Werror -pedantic-errors -Wno-pointer-sign -Wextra -std=gnu11 -ftrapv -g -o"
CHECKMEM="valgrind"
OPTIONS_CHECKMEM="-v --leak-check=full --track-origins=yes --show-leak-kinds=all"

if [ -z $1 ]
then
    if [ -e $SW ]
    then
        if [ ! -e $OBJDIR ]
        then
            mkdir $OBJDIR
        fi
        if [ $SW -nt $SOW ]
        then 
            $CC $SW -c $OPTIONS_CC $SOW --coverage
        fi
        $CC $SOW $OPTIONS_CC $PW --coverage
        echo Run program {y/n}?:
        read ans
        if [ $ans = "y" ]
        then
            echo In testing mode {y/n}?:
            read tst
            if [ $tst = "y" ]
            then
                for file in $TESTDIR/*
                do
                   touch $OBJDIR/$CHECKMEM$var1.txt
                   $CHECKMEM $OPTIONS_CHECKMEM $PW test 2>$OBJDIR/$CHECKMEM$var1.txt
                done
            else
                echo Lets begin!
                $CHECKMEM $OPTIONS_CHECKMEM $PW 2>$OBJDIR/$CHECKMEM$var1.txt
            fi
            echo Run the coverage {y/n}?:
            read answer
            if [ $answer = "y" ]
            then
                if [ -d ./lcov ]
                then
                    echo lcov was installed
                else
                    echo installing lcov
                    git clone https://github.com/linux-test-project/lcov.git
                fi
                lcov --capture --directory $OBJDIR --rc lcov_branch_coverage=1 --output-file $OBJDIR/coverage.info
                genhtml $OBJDIR/coverage.info --branch-coverage -o $OBJDIR/
                echo Have you Firefox in your system {y/n}?
                read brows
                if [ $brows = "y" ]
                then
                    firefox $OBJDIR/index.html
                fi
            fi	
        fi    
    else
        echo You are in wrong direction!!!
    fi
else
    if [ $1 = "clean" ]
    then
        rm -rf $OBJDIR
        if [ -d lcov ]
        then
            rm -rf ./lcov
        fi
    else
        echo There is no option $1
    fi
fi

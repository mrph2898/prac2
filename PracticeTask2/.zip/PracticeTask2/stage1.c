#include <unistd.h>
#include <stdio.h>
//#include <sys/types.h>
#include <fcntl.h>
//#include <sys/stat.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>

enum { BUF_SIZE = 4096 }; 
enum { QUESTIONS_AMNT = 9 };
const char *theme = "Math";
const char *questions[QUESTIONS_AMNT + 1] = {"135 + 230 = ", "400 - 289 = ",
                        "20 * 5 = ", "200 / 50 = ",
                        "Who formulate theorem about 2 cathetus and hypothenus:",
                        "Write natural numbers between 0 and 8:", "sin(pi/2) = ",
                        "e^(ln(15)) = ", "x^2 + 2*x + 1 = 0; What is x? ", (char *)0};
char client_ans[QUESTIONS_AMNT];
const char *answers[QUESTIONS_AMNT + 1] = {"365", "111", "100", "4", "Pifagor", "2 4 6", "1", "15", "-1", (char *)0};
const char *commands = "QqAatT";
const char *comments[3] = {"Incorrect answer!!!", "Good job!!!", (char *)0};

void
verdict(
    int num,  
    const char cor, 
    const int com_cor)
{
    client_ans[num] = cor;
    write(1, comments[com_cor], strlen(comments[com_cor])); 
    putchar('\n');
}

int                                      //function for qsort( *,*,*, comp)
comp (const int *i, const int *j)
{
    return *i - *j;
}

int 
count_amnt_of_num(char *buf) 
{
    int i = 0;
    char *p = buf;
    while (strchr(p, ' ')) {
        p = strchr(p, ' ') + 1; 
        i++;
    }
    return i + 1;
}

int                                          //function_adapt == 0
permutation_ans(char *usr_ans, int num)      //Checking trueness of answer permutation type.
                                             //For example "2 4 6" == "2 6 4" if question was: 
                                             //Write all even numbers in [2,6]
{
    char *ptr_to_enter;
    if ((ptr_to_enter = strchr(usr_ans, '\n')) != 0) {
        usr_ans[ptr_to_enter - usr_ans] = '\0';
    }
    int amnt_of_int_in_ans;
    int amnt_of_int_in_cor_ans;
    char answ[strlen(answers[num])];
    strcpy(answ, answers[num]);
    char *p1 = &answ[0];
    char *p2 = usr_ans;
    int i;
    amnt_of_int_in_cor_ans = count_amnt_of_num(p1); 
    amnt_of_int_in_ans = count_amnt_of_num(p2); 
    int ans[amnt_of_int_in_ans];                    //Now answer is
    int cor_ans[amnt_of_int_in_cor_ans];            //an array of integers
    if (amnt_of_int_in_cor_ans != amnt_of_int_in_ans) {
        return 0;
    } else {
        for (i = 0; i < amnt_of_int_in_ans; i++) {
            sscanf(p1, "%d", &ans[i]);
            p1 = strchr(p1, ' ') + 1; 
            sscanf(p2, "%d", &cor_ans[i]);
            p2 = strchr(p2, ' ') + 1; 
        }
        qsort(ans, amnt_of_int_in_ans, sizeof (int), (int(*) (const void *, const void *)) comp);
        qsort(cor_ans, amnt_of_int_in_ans, sizeof (int), (int(*) (const void *, const void *)) comp);
        if (!(memcmp(ans, cor_ans, (amnt_of_int_in_ans * sizeof(ans[0])) ))) {
            return 1;
        } else { 
            return 0; 
        }
    }
}

int                                     //function_adapt == 1
numeric_ans(char *usr_ans, int num)     //Checking trueness of answer numeric type.
                                        //For example "2" == "2.0" == "02.0" if question was: 
                                        //1 + 1 = 
{
    char *ptr_to_enter;
    if ((ptr_to_enter = strchr(usr_ans, '\n')) != 0) {
        usr_ans[ptr_to_enter - usr_ans] = '\0';
    }
    char *end_ptr1, *end_ptr2;
    float a = strtof(usr_ans, &end_ptr1);
    float b = strtof(answers[num], &end_ptr2);
    if (*end_ptr1) {
        return 0;
    }
    if (errno == ERANGE) {
        return 0;
    }
    if (a == b) { 
        return 1;
    } else {
        return 0;
    }
}

int                                     //function_adapt == 2
str_ans(char *usr_ans, int num)         //Checking trueness of answer string type. Only compare     
{        
    if (!strcasecmp(usr_ans, answers[num])) {     //100% Correct
        return 1;
    } else {                                   //May be correct
        char *ptr_to_enter = strchr(usr_ans, '\n');
        if (!ptr_to_enter) {                           //100% Incorrect
            return 0;
        } else {
            usr_ans[ptr_to_enter - usr_ans] = '\0';    //Delete \n from answer    
            if (!strcasecmp(usr_ans, answers[num])) {  //100% Correct
                return 1;
            } else {                                   //100% Incorrect
                return 0;
            }
        }
    }
}

typedef int (*ArrayOfPtrsToFunc[QUESTIONS_AMNT])(char *str, int num);
ArrayOfPtrsToFunc function_adapts = {numeric_ans, numeric_ans, numeric_ans,
                                     numeric_ans, str_ans, permutation_ans, 
                                     numeric_ans, numeric_ans, numeric_ans};       

int 
main(int argc, char **argv)
{
    if ((argc - 1) > 0) {
        //printf("Test mode");
        if (!strcmp(argv[argc - 1], "test")) {
            int fd;
            fd = open("./Tests/ans", O_RDONLY);
            dup2(fd, 0);
            close(fd);
        } else {
            puts("You weren't go into test");
        }
    }
    char cmd; 
    char answer[BUF_SIZE], *p_to_command;
    int q_num, amnt_of_read_arg;
    int not_so_many_diagn = 0;
    for (int i = 0; i < QUESTIONS_AMNT; i++) {
        client_ans[i] = 'n';
    }
    while (read(0, &cmd, sizeof(cmd)) != 0) {   //While not EOF(CTRL+D)
        if (!(p_to_command = strchr(commands, cmd))) {
            if (!not_so_many_diagn) {
                puts("Wrong command");
                not_so_many_diagn = 1;
            }
            continue;
        }
        switch (*p_to_command) {
        case 'Q':
        case 'q':
            amnt_of_read_arg = scanf("%d", &q_num);
            if ( amnt_of_read_arg == 0 ) {
                puts("You write not a number of question! Try again!");
                break;
            } else if (( q_num > QUESTIONS_AMNT ) || ( q_num < 0 )) {
                puts("You write a big number!!!");
                break;
            }
            write(1, questions[q_num], strlen(questions[q_num]));
            putchar('\n');
            break;
        case 'A':
        case 'a':
            amnt_of_read_arg = scanf("%d", &q_num);
            if ( amnt_of_read_arg == 0 ) {
                puts("You write not a number of question! Try again!");
                break;
            } else if (( q_num > QUESTIONS_AMNT ) || ( q_num < 0 )) {
                puts("You write a big number!!!");
                break;
            }
            if (!read(0, answer, BUF_SIZE)) {
                return 0;     // Need to exit
            }   
            if (function_adapts[q_num](answer, q_num)) {
                verdict(q_num, '+', 1);
            } else {
                verdict(q_num, '-', 0);
            }           
            break;
        case 't':
        case 'T':
            write(1, theme, strlen(theme));
            putchar('\n');
            break;
        }
    }
    printf("%8s", client_ans);
    return 0;
}
